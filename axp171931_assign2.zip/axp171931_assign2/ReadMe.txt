(1)	Naive Bayes
	Compile	:	javac MultinomialNaiveBayes.java
	Run	:	java MultinomialNaiveBayes train test (yes/no)

(2)	Logistic Regression
	Compile	:	javac MCAPLogisticRegression.java
	Run	:	java MCAPLogisticRegression train test (yes/no) (learning rate) (lambda) (iterations)

